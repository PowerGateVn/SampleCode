library authentication_repository;

export 'src/authentication_repository.dart';
