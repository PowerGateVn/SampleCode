// import '../../env_manager.dart';
// //FIXME: should update BASE_URL for environment
// Uri buildUrl(String unencodedPath, [Map<String, String>? queryParameters]) =>
//     Uri.http(
//       EnvManager.shared.get(EnvKey.BASE_URL),
//       unencodedPath,
//       queryParameters,
//     );
