Layout Directory
================

This directory is part of the structure which `angular-folder-structure`
recommends.  For more information about this directory see the
[documentation](https://angular-folder-structure.readthedocs.io/en/latest/layout.html).

