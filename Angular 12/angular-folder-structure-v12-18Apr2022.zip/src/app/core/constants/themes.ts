export const themes = [
  {
    name: 'afs-light-theme'
  },
  {
    name: 'afs-dark-theme'
  }
];
