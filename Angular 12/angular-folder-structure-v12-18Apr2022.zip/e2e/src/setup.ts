import { browser } from 'protractor';

browser.waitForAngularEnabled(false);
