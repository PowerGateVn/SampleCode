Frontend config
============

This folder contains example of frontend config JSON file. By default folder contains just an example file for this.
If you need to override default values just copy ```config_example.json``` to ```config.json``` and make necessary
changes to it. Note that ```config.json``` is ignored from vcs.

Currently this configration file contains following values for frontend side:

<pre>
backendUrl = Sails backend URL, defaults to http://localhost:1337
</pre>