
##  Package managers
This project use Yarn is an allternative package manager for the node built in NPM. Yarn is super-simple to install and use. You can install Yarn use npm by command:  

```bash
npm install -g yarn
```
## Running in dev mode:

```bash
$ yarn
$ yarn run dev
```

## Building production:

```bash
$ yarn 
$ yarn run build
```
## ESLInt Setup with Visual Studio Code:

```
Install [ESLint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint) extension on Visual Studio Code
```
