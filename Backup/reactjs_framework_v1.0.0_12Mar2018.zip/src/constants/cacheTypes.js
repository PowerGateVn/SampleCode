export const cacheTypes = [
  'user',
  'post'
];

export default {
  cacheTypes
};
