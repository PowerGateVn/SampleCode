
export const SERVER_URL = 'https://jsonplaceholder.typicode.com/';

export default {
  SERVER_URL
};
