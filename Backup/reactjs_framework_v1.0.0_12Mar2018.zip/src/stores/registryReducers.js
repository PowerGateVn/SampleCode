import { combineReducers } from 'redux';
import user from '../reducers/user';

const rootReducer = combineReducers({
  user
});
export default rootReducer;
