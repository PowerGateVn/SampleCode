export const UserTypes = {
  GET_USERS: 'GET_USERS',
  CREATE_USER: 'CREATE_USER',
  SELECT_USER: 'SELECT_USER',
  EDIT_USER: 'EDIT_USER',
  UPDATE_USER: 'UPDATE_USER'
};

export default UserTypes;
