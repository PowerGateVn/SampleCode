import { NgModule } from '@angular/core';
import { FeedComponent } from './feed/feed';
@NgModule({
	declarations: [FeedComponent],
	imports: [],
	exports: [FeedComponent]
})
export class ComponentsModule {}
