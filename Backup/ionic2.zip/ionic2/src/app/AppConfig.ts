export class AppConfig {
  public static baseApiUrl = 'http://demo8882897.mockable.io';
}
