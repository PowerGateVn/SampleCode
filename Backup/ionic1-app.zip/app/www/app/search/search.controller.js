angular.module('starter.controllers')
.controller('SearchCtrl', function() {});
