﻿/* global angular */
angular.module('starter.controllers')
  .filter('secondsToDateTime', [function() {
    return function(seconds) {
      return new Date(1970, 0, 1).setSeconds(seconds);
    };
  }])
  .filter('capitalize', function() {
    return function(input) {
      if (input != null) {
        if (input.indexOf(' ') >= 0) {
          var stringArr = input.split(' ');
          var result = '';
          // var cap = stringArr.length;
          result = stringArr[0].charAt(0).toUpperCase() + stringArr[1].charAt(0).toUpperCase();
        } else {
          result = input.charAt(0).toUpperCase() + input.charAt(1).toUpperCase();
        }
        return result;
      }
    };
  });