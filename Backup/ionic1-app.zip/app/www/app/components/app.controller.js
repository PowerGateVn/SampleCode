﻿
angular.module('starter.controllers', ['ionic']).controller('AppCtrl', AppCtrl);
function AppCtrl() {}