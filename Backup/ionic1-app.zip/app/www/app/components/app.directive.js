/* global angular, google, $ */

angular.module('starter.controllers')

  .directive('toggleClass', function() {
    return {
      "restrict": 'A',
      "link": function(scope, element, attrs) {
        element.bind('click', function() {
          element.parent().toggleClass(attrs.toggleClass);
        });
      }
    };
  })
  .directive('numbersOnly', function() {
    return {
      "require": 'ngModel',
      "link": function(scope, element, attr, ngModelCtrl) {
        function fromUser(text) {
          if (text) {
            var transformedInput = text.replace(/[^0-9]/g, '');

            if (transformedInput !== text) {
              ngModelCtrl.$setViewValue(transformedInput);
              ngModelCtrl.$render();
            }
            return transformedInput;
          }
          return undefined;
        }
        ngModelCtrl.$parsers.push(fromUser);
      }
    };
  })
  .directive('changeLocation', function($document) {
    return {
      "restrict": 'EAC', // E = element, A = attribute, C = class, M = comment
      "scope": {
        // @ reads the attribute value, = provides two-way binding, & works with functions
        "ngModel": '=',
        "callback": '&',
        "locationdisable": '=',
      },
      // restrict: 'EC',
      "replace": true,
      "template": '<div class="auto-cpl">' +
                '<input type="text" ng-model="ngModel" ng-change="change(ngModel)" ng-disabled="locationdisable" ng-blur="blurLocation()"  style="{{getStyle()}}" />'
                + '<div class="auto-cpl-result">' +
                '<ul>' +
                '<li ng-repeat="location in arrLocation" ng-click="select(location)">{{location.description}}</li>'
                + '</ul>'
                + '</div>'
                + '</div>',
      "link": function($scope) {

        function documentClick() {
          $scope.arrLocation = [];
        }


        $document.on('click', documentClick);

        // remove event handlers when directive is destroyed

        $scope.arrLocation = [];
        var service = new google.maps.places.AutocompleteService();

        function findLocation(query, cb) {
          var req = {
            "input": query
          };
          service.getQueryPredictions(req, function(predictions, status) {
            if (status == google.maps.places.PlacesServiceStatus.OK) {
              if (typeof cb === 'function') {
                cb(predictions);
              }
            }
          });
        }

        $scope.change = function(query) {

          if (query == '') {
            $scope.arrLocation = [];
            return;
          }
          findLocation(query, function(data) {
            $scope.arrLocation = data;
          });
        };

        $scope.select = function(location) {
          $scope.ngModel = location.description;
          $scope.$eval($scope.callback({ "data": location.description }));
          $scope.arrLocation = [];
        };

        $scope.blurLocation = function() {

          $scope.$eval($scope.callback({ "data": $scope.ngModel }));
        };

        $scope.getStyle = function() {
          if ($scope.locationdisable) {
            return 'background-color: #efefef !important;color: #9e9e9e !important;';
          }

        };
      }
    };
  })
  .directive('outsideClick', ['$document', '$parse', function($document) {
    return {
      "link": function($scope, $element, $attributes) {
        var scopeExpression = $attributes.outsideClick,
          onDocumentClick = function(event) {
            var isChild = $element.find(event.target).length > 0;

            if (!isChild) {
              $scope.$apply(scopeExpression);
            }
          };

        $document.on('click', onDocumentClick);

        $element.on('$destroy', function() {
          $document.off('click', onDocumentClick);
        });
      }
    };
  }])
  .directive('autoSelect', function($document, $ionicScrollDelegate) {
    return {
      // restrict: 'EAC', //E = element, A = attribute, C = class, M = comment
      "scope": {
        // @ reads the attribute value, = provides two-way binding, & works with functions
        "ngModel": '=',
        "items": '=data',
        "multi": '=',
        "callback": '&',
        "outInput": '&'
      },
      "restrict": 'EC',
      "replace": true,
      "template": '<div class="auto-cpl" outside-click="blurDirective()">' +
                '<input type="text" ng-model="ngModel" ng-change="change(ngModel)" ng-blur="blurInput()" ng-click="openSelect()"/>'
                + '<button class="auto-btn" type="button" ng-if="ngModel && ngModel.length > 0" ng-click="remove()">x</button>'
                + '<div class="auto-result-scroll" ng-if="open">'
                + '<ion-scroll class="auto-scroll" delegate-handle="small">'
                + '<div class="auto-cpl-result-select">'
                + '<ul>'
                + '<li ng-repeat="item in items" ng-if="item.show" ng-click="select(item)">{{item.display}}</li>'
                + '</ul>'
                + '</div>'
                + '</ion-scroll>'
                + '</div>'
                + '</div>',
      "link": function($scope) {
        $scope.open = false;
        $scope.isSelect = false;
        $scope.data = {};
        // remove event handlers when directive is destroyed

        $scope.blurInput = function() {

          $scope.$eval($scope.callback({ "data": $scope.data }));
        };


        // function query search for auto complete
        $scope.change = function(query) {
          $scope.data = {};
          $ionicScrollDelegate.$getByHandle('small').scrollTop();

          angular.forEach($scope.items, function(value) {
            if ($scope.multi) {
              value.show = (value.display.toLowerCase().indexOf(query.toLowerCase()) > -1) ||
                                value.abbreviation.toLowerCase().indexOf(query.toLowerCase()) > -1;

            } else {
              value.show = (value.display.toLowerCase().indexOf(query.toLowerCase()) > -1);

            }
          });
        };

        $scope.remove = function() {
          $scope.data = {};
          $scope.ngModel = '';
          angular.forEach($scope.items, function(value) {
            value.show = true;
          });
          $scope.isSelect = false;
        };

        $scope.openSelect = function() {
          $ionicScrollDelegate.$getByHandle('small').scrollTop();
          $scope.open = true;
        };

        $scope.blurDirective = function() {
          $scope.open = false;
        };

        $scope.select = function(value) {
          $scope.data = value;
          $scope.ngModel = value.display;
          $scope.open = false;
          $scope.isSelect = true;
          $scope.$eval($scope.callback({ "data": value }));
        };
      }
    };
  })
  .directive('detectFocus', function() {
    return {
      "restrict": 'A',
      "scope": {
        "onFocus": '&onFocus',
        "onBlur": '&onBlur',
        "focusOnBlur": '=hideKeyboard'
      },
      "link": function(scope, elem) {

        elem.on('focus', function() {
          scope.onFocus();
        });

        elem.on('blur', function() {
          if (scope.focusOnBlur) {
            elem[0].focus();
          }
        });
      }
    };
  })
  .directive('addWhoCz', function($timeout) {
    return {
      "restrict": 'A',
      "link": function(scope, element) {
        if (scope.$last) {
          $timeout(function() {
            // console.log('This is directive add who');
            element.parent('.multipleSelectCz').select2({
              "tags": true
            });
          }, 100);
        }
      }
    };
  })
  .directive('datepickerCz', function() {
    return {
      "restrict": 'A',
      "link": function(scope, element) {
        element.find('#datetimepicker12').datetimepicker({
          "inline": true,
          "format": 'dd/mm/yyyy',
          "sideBySide": true
        }).on('dp.change', function() {
          // console.log(e.date._d);
        });

      }
    };
  })
  .directive('changeColorUser', function() {
    return {
      "restrict": 'A',
      "link": function() {
        // console.log('This is directive for change user color');

        $('.dropdown-user .uc-display').click(function() {
          $('.dropdown-user .uc-list-color ul').toggle();
        });

        $('.dropdown-user .uc-list-color ul li a').click(function() {
          var text = $(this).html();
          $('.dropdown-user .uc-display a').html(text);
          $('.dropdown-user .uc-list-color ul').hide();
        });
      }
    };
  })
  .directive('dirDayOfWeek', function() {
    return {
      "restrict": 'A',
      "link": function(scope, element) {
        // console.log('This is dir day of week');

        element.find('.view-choice').click(function() {
          $('.box-day-of-week ul').toggle();
        });

        element.find('.list-choice-cz ul li a').click(function() {
          var person = $(this).text();
          $('.box-day-of-week .view-choice .text-placehodel').css('display', 'none');
          $('.box-day-of-week .view-choice').append(person + ', ');
          $(this).remove();
          // var attrWhoId = $(this).attr('data-attribute');
          // console.log($(this).attr('data-attribute'));
          // $('.value-format-addhow').append(attrWhoId + ',');
          if (!$('.box-day-of-week .list-choice-cz ul li a').length) {
            $('.box-day-of-week .list-choice-cz').css('display', 'none');
          }
        });
      }
    };
  })
  .directive('limitTo', [function() {
    return {
      "restrict": 'A',
      "link": function(scope, elem, attrs) {
        var limit = parseInt(attrs.limitTo);
        angular.element(elem).on('keypress', function(e) {
          if (this.value.length == limit) { e.preventDefault(); }
        });
      }
    };
  }])
  .directive('myDayOfWeek', function() {
    return {
      // restrict: 'EAC', //E = element, A = attribute, C = class, M = comment
      "scope": {
        // @ reads the attribute value, = provides two-way binding, & works with functions
        "ngModel": '=',
        "error": '='
      },
      "restrict": 'EC',
      "replace": true,
      // template: '<div>abc</div>',
      "template": '<div>'
                + '<div class="select-day-of-week" outside-click="blurSelectDayOfWeek()" ng-click="openToSelectDayOfWeek()" ng-class="getClass()">'
                + '<ul class="day-of-week-list">'
                + '<li class="item" ng-repeat="weekday in ngModel" ng-if="weekday.selected">'
                + '<span>{{weekday.name}}</span>'
                + '<a class="item-remove" ng-click="removeDayOfWeek(weekday)">x</a>'
                + '</li>'
                + '</ul>'
                + '</div>'
                + '<div class="auto-cpl auto-cpl-tags autocomplete" ng-if="openSelectDayOfWeek">'
                + '<div class="auto-cpl-result auto-cpl-tags-item  suggestion-list">'
                + '<ul>'
                + '<li ng-repeat="weekday in ngModel" ng-if="!weekday.selected" ng-click="selectDayOfWeek(weekday)">{{weekday.name}}</li>'
                + '</ul>'
                + '</div>'
                + '</div>'
                + '</div>',
      "link": function($scope) {
        //
        $scope.getClass = function() {
          return ($scope.error) ? 'error-red' : '';
        };
        // console.log();
        $scope.openSelectDayOfWeek = false;
        // click to other filed dayofweek. hide list dayofweek
        $scope.blurSelectDayOfWeek = function() {
          var now = new Date().getTime();
          if (now - $scope.inside > 100) {
            $scope.openSelectDayOfWeek = false;
          }
        };

        // when click to filed dayofWeek . open the div select day of week
        $scope.openToSelectDayOfWeek = function() {
          $scope.inside = new Date().getTime();
          $scope.openSelectDayOfWeek = true;
        };

        // when click to 'X' button . remove select day of week
        $scope.removeDayOfWeek = function(item) {
          item.selected = false;
        };

        $scope.selectDayOfWeek = function(item) {
          item.selected = true;
          $scope.openSelectDayOfWeek = false;
        };
      }
    };
  })
  .directive('outsideClick', ['$document', function($document) {
    return {
      "link": function($scope, $element, $attributes) {
        var scopeExpression = $attributes.outsideClick,
          onDocumentClick = function(event) {
            var isChild = $element.find(event.target).length > 0;

            if (!isChild) {
              $scope.$apply(scopeExpression);
            }
          };

        $document.on('click', onDocumentClick);

        $element.on('$destroy', function() {
          $document.off('click', onDocumentClick);
        });
      }
    };
  }]);