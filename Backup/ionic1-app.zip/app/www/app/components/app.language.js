﻿var CONNECTION_ERROR = 'Connection error';

