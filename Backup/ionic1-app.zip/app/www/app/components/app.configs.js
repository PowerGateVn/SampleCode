﻿app.config(routeConfig);


function routeConfig($stateProvider, $urlRouterProvider, $ionicConfigProvider) {
  $ionicConfigProvider.views.maxCache(0);
  $stateProvider
   
    .state('app', {
      url: '/app',
      abstract: true,
      "templateUrl": 'app/components/menu.html',
      controller: 'AppCtrl'
    })
    .state('app.home', {
      "url": '/home',
      "views": {
        'menuContent': {
          "templateUrl": 'app/home/home.html',
          "controller": "HomeCtrl"
        }
      },
    })
    .state('app.browse', {
      "url": '/browse',
      "views": {
        'menuContent': {
          "templateUrl": 'app/browse/browse.html',
          "controller": "BrowseCtrl"
        }
      },
    }) 
    .state('app.search', {
      "url": '/search',
      "views": {
        'menuContent': {
          "templateUrl": 'app/browse/browse.html',
          "controller": "SearchCtrl"
        }
      },
    });
    $urlRouterProvider.otherwise('/app/home');


}
