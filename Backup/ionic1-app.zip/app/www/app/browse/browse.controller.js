angular.module('starter.controllers')
.controller('BrowseCtrl', function() {});
