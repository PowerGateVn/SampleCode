### :point_right: These resources have been moved to the [ionic-team/starters](https://github.com/ionic-team/starters/tree/master/integrations/cordova/resources) repo! :point_left:
