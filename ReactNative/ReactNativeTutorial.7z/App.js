import boot from "./src/boot/index";

const app = boot();

export default app;
