<?php
namespace Infos\Users\Repository\Interfaces;

/**
 * Interface UserRepositoryInterface
 * @package Informatics\Blog\Repository\Interfaces
 */
interface UserRepositoryInterface {
}
